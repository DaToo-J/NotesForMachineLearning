# 一、 数据分析

## a. 各变量之间的相关性

```python
# 利用协方差矩阵绘制热力图
train_corr = train_data.corr()
sns.heatmap(train_corr, vmin=-1, vmax=1, annot=True )
```



![1562815774264](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562815774264.png)

## b. 各变量与离散目标变量的关系

### （1）离散特征变量 

*默认目标变量为离散变量，更准确点则是二分类*



#### **1.1 groupby**

- 适合：聚合分类查看特征变量与目标变量直接的数值关系，同类内可以互相比较，不同类间比较不那么方便；

- ```python
  train_data.groupby(['Sex','Survived'])['Survived'].count()
  ```

  - ![1562816535183](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562816535183.png)





#### **1.2 直方图**

- method 1 —— 适合：当目标变量为0/1二分类，运用mean()，得到的是聚合分类之后，值为‘1’的占比

- ```python
  # data[['class1','class2']].groupby(['class1 or class2']).mean().plot.bar()
  
  train_data[['Sex','Survived']].groupby(['Sex']).mean().plot.bar()
  train_data[['Sex','Pclass','Survived']].groupby(['Pclass','Sex']).mean().plot.bar()
  
  ```

  - | ![1562824693951](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562824693951.png) | ![1562825027283](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562825027283.png) |
    | ------------------------------------------------------------ | ------------------------------------------------------------ |
    | ['Sex','Survived']                                           | ['Sex','Pclass','Survived']                                  |





- method 2 —— 适合：先按一个变量进行分类，再按另一个变量分类显示的直方图

- ```python
  # sns.countplot('class1',hue='class2',data=train_data)
  
  sns.countplot('Pclass',hue='Survived',data=train_data)
  # countplot : 计数直方图，通过hue参数指定分类别的显示
  ```

  - ![1562824920768](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562824920768.png)

- method 3 —— 适合：变量虽然离散，但是取值较多。

- ```python
  g = sns.FacetGrid(train_data, col='Survived')
  g.map(plt.hist, 'Age', bins=20)
  
  # g = sns.FacetGrid(train_data, col='class1')
  # g.map(plt.hist, 'class2', bins=20)
  
  # FacetGrid ： 画出轮廓； map ： 填充内容
  # hist：直方图； scatter：散点图； barplot：条形图；
  
  
  # -----------------------------------------------------
  f, [ax1, ax2] = plt.subplots(1, 2, figsize=(20, 5))
  sns.countplot(x='SibSp', hue='Survived', data=train_data, ax=ax1)
  sns.countplot(x='Parch', hue='Survived', data=train_data, ax=ax2)
  ax1.set_title('SibSp ')
  ax2.set_title('Parch ')
  ```

  - | ![1562825203043](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562825203043.png) | ![1562825801286](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562825801286.png) |
    | ------------------------------------------------------------ | ------------------------------------------------------------ |
    | 年龄与生存关系的直方图                                       | SibSp和 Parch 两个变量，两个子图                             |

    

#### **1.3 饼图** 

- 适合：特征变量、目标变量的取值个数较少，组合之后不会有很多类别；

- ```python
  train_data.groupby(['Sex','Survived'])['Survived'].count().plot.pie(autopct='%1.1f%%')
  
  # 性别 VS 生存 ：组合类别少，同类内可以相互比较
  ```

  - ![1562816303433](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562816303433.png)

