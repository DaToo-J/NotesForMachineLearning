- [zhihu titanic](https://zhuanlan.zhihu.com/p/30538352)
- [zhihu github code](https://github.com/Arctanxy/Titanic_Voting_Classifier/blob/master/VotingClassifier.py)
- [csdn titanic](https://blog.csdn.net/qq_41127512/article/details/78957914)

# 一、 数据分析

## a. 各变量之间的相关性

```python
# 利用协方差矩阵绘制热力图
train_corr = train_data.corr()
sns.heatmap(train_corr, vmin=-1, vmax=1, annot=True )
```



![1562815774264](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562815774264.png)

## b. 各变量与离散目标变量的关系

### （1）离散特征变量 

*默认目标变量为离散变量，更准确点则是二分类*



#### **1.1 groupby**

- 适合：聚合分类查看特征变量与目标变量直接的数值关系，同类内可以互相比较，不同类间比较不那么方便；

- ```python
  train_data.groupby(['Sex','Survived'])['Survived'].count()
  ```

  - ![1562816535183](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562816535183.png)





#### **1.2 直方图**

- method 1 —— 适合：当目标变量为0/1二分类，运用mean()，得到的是聚合分类之后，值为‘1’的占比

- ```python
  # data[['class1','class2']].groupby(['class1 or class2']).mean().plot.bar()
  
  train_data[['Sex','Survived']].groupby(['Sex']).mean().plot.bar()
  train_data[['Sex','Pclass','Survived']].groupby(['Pclass','Sex']).mean().plot.bar()
  
  ```

  - | ![1562824693951](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562824693951.png) | ![1562825027283](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562825027283.png) |
    | ------------------------------------------------------------ | ------------------------------------------------------------ |
    | ['Sex','Survived']                                           | ['Sex','Pclass','Survived']                                  |





- method 2 —— 适合：先按一个变量进行分类，再按另一个变量分类显示的直方图

- ```python
  # sns.countplot('class1',hue='class2',data=train_data)
  
  sns.countplot('Pclass',hue='Survived',data=train_data)
  # countplot : 计数直方图，通过hue参数指定分类别的显示
  ```

  - ![1562824920768](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562824920768.png)

- method 3 —— 适合：变量虽然离散，但是取值较多。

- ```python
  g = sns.FacetGrid(train_data, col='Survived')
  g.map(plt.hist, 'Age', bins=20)
  
  # g = sns.FacetGrid(train_data, col='class1')
  # g.map(plt.hist, 'class2', bins=20)
  
  # FacetGrid ： 画出轮廓； map ： 填充内容
  # hist：直方图； scatter：散点图； barplot：条形图；
  
  
  # -----------------------------------------------------
  f, [ax1, ax2] = plt.subplots(1, 2, figsize=(20, 5))
  sns.countplot(x='SibSp', hue='Survived', data=train_data, ax=ax1)
  sns.countplot(x='Parch', hue='Survived', data=train_data, ax=ax2)
  ax1.set_title('SibSp ')
  ax2.set_title('Parch ')
  ```

  - | ![1562825203043](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562825203043.png) | ![1562825801286](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562825801286.png) |
    | ------------------------------------------------------------ | ------------------------------------------------------------ |
    | 年龄与生存关系的直方图                                       | SibSp和 Parch 两个变量，两个子图                             |

    

#### **1.3 饼图** 

- 适合：特征变量、目标变量的取值个数较少，组合之后不会有很多类别；

- ```python
  train_data.groupby(['Sex','Survived'])['Survived'].count().plot.pie(autopct='%1.1f%%')
  
  # 性别 VS 生存 ：组合类别少，同类内可以相互比较
  ```

  - ![1562816303433](C:\Users\Datoo\AppData\Roaming\Typora\typora-user-images\1562816303433.png)





# 二、 集成学习



1. **同质的** (homogeneous) VS **异质的** (heterogeneous)：集成中包含的个体学习器是否都是同种类型
   - 同质 -> 基学习器 (base learner) 、 基学习算法(base learning algorithm)
   - 异质 -> 组件学习器(component learner)、个体学习器(individual learner)
2. 要求：个体学习器好而不同：a. 有一定**准确性**，不能太坏；b. 要有**多样性**，学习器之间有差异；
   - 但是准确性和多样性存在冲突：准确性提高之后，要增加多样性就得牺牲准确性
3. 分类
   - 个体学习器间**存在强依赖关系**、必须**串行生成**的序列化方法：**boosting** —— 所有个体学习器加权求和
   - 个体学习器间**不存在强依赖关系**、可**同时生成**的并行化方法：**bagging、随机森林** —— 基于数据随机重抽样分类器构造的方法



## a. Boosting

1. 工作机制：
   - 初始训练集中，训练一个基学习器
   - 根据基学习器的表现对训练样本进行调整，使得基学习器做错的训练样本在后续学习中得到**更多的关注**
   - 调整样本分布，再训练下一个基学习器
   - 直到基学习器的个数达到指定值T
   - 将这T个基学习器进行加权结合
2. 一句话解释：**通过调整已有基学习器错分的数据来学习新的基学习器，最后对多个基学习器加权求和，得到最优结果；**
3. 代表算法：
   - **AdaBoost**：
     - 通过增加分错样本 **权重** 来“关注分错样本”
     - 有许多推导式，其一有基于加性模型(additive model)，即基学习器的线性组合来最小化指数损失函数
   - **Gradient Boosting**：
     - 将负梯度作为上一轮基学习器犯错的衡量指标，在下一轮学习中通过拟合负梯度来纠正上一轮的犯错

### AdaBoost

*Adaptive Boosting：自适应boosting*

- **工作机制**

  1. 给训练数据 N个 样本赋予一个权重，这些权重构成**向量**。

     - $向量D^{(t)} = [\frac1N ... \frac1N]$ 

       

  2. 第一次训练：得到 弱分类器 + 及其**错误率 和 权重**。

     - **错误率**：$\epsilon = \sum_{i=1}^N D_i^{(t)} I(H_t(x_i) \neq y_i)$ 

       - $i = [1, N];   \ t = [1, T]$ (N个样本， T个分类器)

       - 分错样本的权重相加

       - $ \epsilon = \frac{分错的样本数}{总样本数}$ —— (只有第一次训练是这样的)

         

     - **分类器权重**：

       - 检查错误率是否小于0.5，否则，丢弃分类器，还不如随机猜测

       - $ \alpha_t = \frac12ln(\frac{1-\epsilon}{\epsilon})$

         

  3. 第二次训练：在同一数据集上，调整每个样本的权重，即提高分错样本的权重，降低分对样本的权重。

     - 分对样本的权重：$D_i^{(t+1)} = \frac{D_i^{(t)} e^{-\alpha}}{Sum(D)}$
     - 分错样本的权重：$D_i^{(t+1)} = \frac{D_i^{(t)} e^{\alpha}}{Sum(D)}$

  4. 得到最终分类器：

     - $H(x) = sign(\sum_1^T \alpha_t h_t(x))$

       

- **公式推导**
  1. 基学习器的线性组合：$H(x) = sign(\sum_1^T \alpha_t h_t(x))$
  2. 最小化指数损失函数：
     - $L(x) = e^{-f(x_i)\alpha_th_t(x_i)}$
     - $ \ \ \ \ \ \ \ \ = e^{-\alpha_t} \mathcal I[f(x_i) = h_t(x_i)] + e^{\alpha_t} \mathcal I[f(x_i) \neq h_t(x_i)]$
     - ​               *(会对所有$x_i$进行遍历，所以和错误率有关)*
     - $ \ \ \ \ \ \ \ \ = e^{- \alpha_t}(1 - \epsilon_t) +  e^{ \alpha_t}\epsilon_t$
     - $\mathcal I(x)$：指示函数，x为真时值为1，x为假时值为0
  3. 对$\alpha_t$ 求偏导：$\frac{dL(x)}{d\alpha_t} =  - e^{- \alpha_t}(1 - \epsilon_t) +  e^{ \alpha_t}\epsilon_t$
  4. 令其等于零：$\alpha_t = \frac12ln(\frac{1- \epsilon_t}{\epsilon_t})$，为分类器权重更新公式

- **面试题**
  1. 手推AdaBoost
  2. 与GBDT比较
  3. AdaBoost几种基本机器学习算法哪个抗噪能力最强，哪个对重采样不敏感？



- 参考：
  1. [adaboost csdn blog](https://www.cnblogs.com/ScorpioLu/p/8295990.html)
  2. [github tutorial]([https://github.com/apachecn/AiLearning/blob/master/docs/ml/7.%E9%9B%86%E6%88%90%E6%96%B9%E6%B3%95-%E9%9A%8F%E6%9C%BA%E6%A3%AE%E6%9E%97%E5%92%8CAdaBoost.md](https://github.com/apachecn/AiLearning/blob/master/docs/ml/7.集成方法-随机森林和AdaBoost.md))

## b. Bagging

















### Random Forest

















